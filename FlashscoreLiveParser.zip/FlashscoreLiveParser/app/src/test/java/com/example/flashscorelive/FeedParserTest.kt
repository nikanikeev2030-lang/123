package com.example.flashscorelive

import com.example.flashscorelive.data.FeedParser
import com.example.flashscorelive.data.MatchStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Unit-тесты парсера feed Flashscore на встроенном снапшоте:
 * 2 лиги, 3 матча (live со счётом и минутой, запланированный, завершённый).
 */
class FeedParserTest {

    /**
     * Реалистичный фрагмент feed.
     * Формат: записи разделены '¬', поля внутри записи — '~' (КЛЮЧ~значение).
     *
     * Первая лига: АНГЛИЯ: Премьер-лига — live-матч (минута 45+2, счёт 2:1)
     * и запланированный матч (только timestamp начала).
     * Вторая лига: ИСПАНИЯ: ЛаЛига — завершённый матч (стадия FT, счёт 1:0).
     */
    private val snapshot: String = buildString {
        // Заголовок первой лиги
        append("ZA~Премьер-лига~ZB~Англия~ZC~ENG~¬")
        // Live-матч: минута 45+2, счёт 2:1
        append("AA~match001~AD~1724500000~AB~1~AE~Арсенал~AF~Челси~AG~2~AH~1~BA~1~BB~0~AO~45+2~¬")
        // Запланированный матч: только время начала
        append("AA~match002~AD~1724523600~AB~1~AE~Ливерпуль~AF~Эвертон~¬")
        // Заголовок второй лиги
        append("ZA~ЛаЛига~ZB~Испания~¬")
        // Завершённый матч: стадия FT, счёт 1:0 (начался давно)
        append("AA~match003~AD~1724400000~AB~FT~AE~Реал Мадрид~AF~Барселона~AG~1~AH~0~BA~0~BB~0~¬")
        // Лишний «мусорный» фрагмент — парсер должен его проигнорировать
        append("XX~something~YY~other")
    }

    @Test
    fun `разбираются обе лиги`() {
        val leagues = FeedParser.parse(snapshot)
        assertEquals(2, leagues.size)
        assertEquals("Премьер-лига", leagues[0].name)
        assertEquals("Англия", leagues[0].country)
        assertEquals("ЛаЛига", leagues[1].name)
        assertEquals("Испания", leagues[1].country)
    }

    @Test
    fun `live-матч разбирается со счётом и минутой`() {
        val leagues = FeedParser.parse(snapshot)
        val live = leagues[0].matches[0]
        assertEquals("match001", live.id)
        assertEquals("Арсенал", live.home)
        assertEquals("Челси", live.away)
        assertEquals(2, live.homeScore)
        assertEquals(1, live.awayScore)
        assertEquals("45+2", live.minute)
        assertEquals(MatchStatus.LIVE, live.status)
        assertEquals(1724500000L, live.startTimestamp)
        assertEquals("Премьер-лига", live.leagueName)
    }

    @Test
    fun `запланированный матч без счёта`() {
        val leagues = FeedParser.parse(snapshot)
        val scheduled = leagues[0].matches[1]
        assertEquals("match002", scheduled.id)
        assertEquals("Ливерпуль", scheduled.home)
        assertEquals("Эвертон", scheduled.away)
        assertNull(scheduled.homeScore)
        assertNull(scheduled.awayScore)
        assertNull(scheduled.minute)
        assertEquals(MatchStatus.SCHEDULED, scheduled.status)
    }

    @Test
    fun `завершённый матч определяется по стадии FT`() {
        val leagues = FeedParser.parse(snapshot)
        val finished = leagues[1].matches[0]
        assertEquals("match003", finished.id)
        assertEquals(1, finished.homeScore)
        assertEquals(0, finished.awayScore)
        assertEquals(MatchStatus.FINISHED, finished.status)
    }

    @Test
    fun `пустой ответ 0 не ошибка`() {
        assertTrue(FeedParser.parse("0").isEmpty())
        assertTrue(FeedParser.parse("").isEmpty())
        assertTrue(FeedParser.parse(null).isEmpty())
    }

    @Test
    fun `лига без матчей не попадает в результат`() {
        // Заголовок лиги, за которым нет ни одного матча
        val body = "ZA~Пустая лига~ZB~Нигде~¬ZA~Премьер-лига~ZB~Англия~¬AA~m1~AD~1724500000~AE~А~AF~Б"
        val leagues = FeedParser.parse(body)
        assertEquals(1, leagues.size)
        assertEquals("Премьер-лига", leagues[0].name)
        assertEquals(1, leagues[0].matches.size)
    }

    @Test
    fun `первая пара полей без ведущего разделителя`() {
        val body = "ZA~Лига~ZB~Страна~¬AA~m1~AD~1724500000~AB~1~AE~А~AF~Б~AG~3~AH~3~AO~78"
        val leagues = FeedParser.parse(body)
        assertEquals("m1", leagues[0].matches[0].id)
        assertEquals("78", leagues[0].matches[0].minute)
        assertEquals(MatchStatus.LIVE, leagues[0].matches[0].status)
    }
}
