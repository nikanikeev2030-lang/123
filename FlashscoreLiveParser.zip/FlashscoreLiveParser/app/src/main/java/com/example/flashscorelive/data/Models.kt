package com.example.flashscorelive.data

/**
 * Модель футбольного матча из feed Flashscore.
 *
 * @param id          уникальный идентификатор матча (поле AA)
 * @param home        название домашней команды (поле AE)
 * @param away        название гостевой команды (поле AF)
 * @param homeScore   счёт домашних, null если счёт ещё не открыт (поле AG)
 * @param awayScore   счёт гостей, null если счёт ещё не открыт (поле AH)
 * @param minute      текущая минута матча, например "45+2" (поле AO), может быть null
 * @param status      текстовый статус матча (вычисляется из полей AB/AJ)
 * @param startTimestamp unix-timestamp начала матча в секундах (поле AD), может быть null
 * @param leagueName  название лиги, к которой относится матч
 */
data class Match(
    val id: String,
    val home: String,
    val away: String,
    val homeScore: Int?,
    val awayScore: Int?,
    val minute: String?,
    val status: MatchStatus,
    val startTimestamp: Long?,
    val leagueName: String,
)

/** Статус матча. */
enum class MatchStatus {
    /** Матч идёт прямо сейчас. */
    LIVE,
    /** Матч ещё не начался. */
    SCHEDULED,
    /** Матч завершён. */
    FINISHED,
    /** Перерыв. */
    HALF_TIME,
    /** Статус не удалось определить. */
    UNKNOWN,
}

/**
 * Лига/турнир с её матчами.
 *
 * @param name    название лиги (поле ZA)
 * @param country страна (поле ZB)
 * @param matches матчи этой лиги
 */
data class League(
    val name: String,
    val country: String,
    val matches: List<Match>,
)
