package com.example.flashscorelive.data

/**
 * Репозиторий матчей: инкапсулирует логику «live, иначе — матчи дня».
 */
class MatchRepository(
    private val api: FlashscoreApi = FlashscoreApi(),
) {

    /**
     * Результат загрузки матчей.
     *
     * @param leagues  разобранные лиги с матчами
     * @param isLive   true, если показаны live-матчи; false — fallback на матчи дня
     * @param isError  true, если не удалось загрузить ни один из feed'ов (ошибка сети)
     */
    data class Result(
        val leagues: List<League>,
        val isLive: Boolean,
        val isError: Boolean,
    )

    /**
     * Загружает live-матчи. Если live-feed пуст (тело == "0" или сеть вернула
     * пустые данные) — загружает матчи на сегодня как fallback.
     */
    suspend fun loadMatches(): Result {
        val liveBody = api.fetchLive()
        if (liveBody != null) {
            val leagues = FeedParser.parse(liveBody)
            if (leagues.isNotEmpty()) {
                return Result(leagues, isLive = true, isError = false)
            }
            // Live пуст ("0") — это не ошибка, переходим к матчам дня
        }

        val todayBody = api.fetchToday()
        if (todayBody != null) {
            val leagues = FeedParser.parse(todayBody)
            // Если оба feed'а пусты, но сеть работала — просто «матчей нет»
            return Result(leagues, isLive = false, isError = false)
        }

        // Ни один запрос не удался — ошибка сети
        return Result(emptyList(), isLive = false, isError = true)
    }
}
