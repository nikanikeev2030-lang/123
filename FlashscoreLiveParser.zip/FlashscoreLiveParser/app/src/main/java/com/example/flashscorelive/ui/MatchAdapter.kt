package com.example.flashscorelive.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.flashscorelive.R
import com.example.flashscorelive.data.League
import com.example.flashscorelive.data.Match
import com.example.flashscorelive.data.MatchStatus
import com.example.flashscorelive.databinding.ItemLeagueBinding
import com.example.flashscorelive.databinding.ItemMatchBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Адаптер списка матчей: заголовки лиг + строки матчей.
 */
class MatchAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    /** Элемент списка: либо заголовок лиги, либо матч. */
    sealed interface Item {
        data class LeagueHeader(val name: String, val country: String) : Item
        data class MatchRow(val match: Match) : Item
    }

    private val items = mutableListOf<Item>()

    /** Полностью заменяет данные списка. */
    fun submit(leagues: List<League>) {
        items.clear()
        for (league in leagues) {
            items += Item.LeagueHeader(league.name, league.country)
            league.matches.forEach { items += Item.MatchRow(it) }
        }
        notifyDataSetChanged()
    }

    override fun getItemViewType(position: Int): Int = when (items[position]) {
        is Item.LeagueHeader -> VIEW_TYPE_LEAGUE
        is Item.MatchRow -> VIEW_TYPE_MATCH
    }

    override fun getItemCount(): Int = items.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return when (viewType) {
            VIEW_TYPE_LEAGUE -> LeagueViewHolder(
                ItemLeagueBinding.inflate(inflater, parent, false)
            )
            else -> MatchViewHolder(
                ItemMatchBinding.inflate(inflater, parent, false)
            )
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (val item = items[position]) {
            is Item.LeagueHeader -> (holder as LeagueViewHolder).bind(item)
            is Item.MatchRow -> (holder as MatchViewHolder).bind(item)
        }
    }

    /** Заголовок лиги. */
    private class LeagueViewHolder(
        private val binding: ItemLeagueBinding,
    ) : RecyclerView.ViewHolder(binding.root) {
        fun bind(item: Item.LeagueHeader) {
            binding.leagueName.text =
                if (item.country.isBlank()) item.name
                else "${item.country}: ${item.name}"
        }
    }

    /** Строка матча. */
    private class MatchViewHolder(
        private val binding: ItemMatchBinding,
    ) : RecyclerView.ViewHolder(binding.root) {

        private val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())

        fun bind(item: Item.MatchRow) {
            val match = item.match
            binding.homeTeam.text = match.home
            binding.awayTeam.text = match.away

            // Счёт: если голов ещё нет — показываем прочерк
            val homeScore = match.homeScore?.toString() ?: "–"
            val awayScore = match.awayScore?.toString() ?: "–"
            binding.score.text = "$homeScore : $awayScore"

            // Правая колонка: минута/статус/время начала
            binding.status.text = statusText(match)
            val statusColor = when (match.status) {
                MatchStatus.LIVE -> R.color.match_live
                MatchStatus.HALF_TIME -> R.color.match_halftime
                MatchStatus.FINISHED -> R.color.match_finished
                else -> R.color.match_scheduled
            }
            binding.status.setTextColor(
                binding.root.context.getColor(statusColor)
            )
        }

        private fun statusText(match: Match): String = when (match.status) {
            MatchStatus.LIVE -> match.minute?.let { "$it′" }
                ?: binding.root.context.getString(R.string.status_live)
            MatchStatus.HALF_TIME -> binding.root.context.getString(R.string.status_halftime)
            MatchStatus.FINISHED -> binding.root.context.getString(R.string.status_finished)
            MatchStatus.SCHEDULED -> match.startTimestamp?.let { timeFormat.format(Date(it * 1000)) }
                ?: binding.root.context.getString(R.string.status_scheduled)
            MatchStatus.UNKNOWN -> match.startTimestamp?.let { timeFormat.format(Date(it * 1000)) } ?: ""
        }
    }

    private companion object {
        const val VIEW_TYPE_LEAGUE = 0
        const val VIEW_TYPE_MATCH = 1
    }
}
