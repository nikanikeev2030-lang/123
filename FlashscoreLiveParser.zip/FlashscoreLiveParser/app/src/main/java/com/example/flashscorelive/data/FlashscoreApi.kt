package com.example.flashscorelive.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

/**
 * Клиент внутреннего feed Flashscore.
 *
 * Публичного API у Flashscore нет, поэтому используется тот же текстовый
 * feed, что и у мобильного сайта, с обязательным заголовком `x-fsign`.
 */
class FlashscoreApi {

    companion object {
        /** Live-матчи футбола. */
        private const val URL_LIVE = "https://d.flashscore.com/x/feed/f_1_0_3_ru_1"

        /** Матчи на сегодня (fallback, если live пуст). */
        private const val URL_TODAY = "https://d.flashscore.com/x/feed/f_1_0_1_ru_1"

        /** Обязательный заголовок подписи feed (может меняться со временем!). */
        private const val HEADER_FSIGN = "SW9D1eZo"

        private const val USER_AGENT =
            "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/124.0 Mobile"
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    /** Загружает текст live-feed. При ошибке сети возвращает null. */
    suspend fun fetchLive(): String? = get(URL_LIVE)

    /** Загружает текст feed матчей на сегодня. При ошибке сети возвращает null. */
    suspend fun fetchToday(): String? = get(URL_TODAY)

    /**
     * Выполняет GET-запрос с обязательными заголовками.
     *
     * @return тело ответа как String или null при любой ошибке (сеть, не-2xx).
     */
    private suspend fun get(url: String): String? = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder()
                .url(url)
                .header("x-fsign", HEADER_FSIGN)
                .header("User-Agent", USER_AGENT)
                .build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext null
                response.body?.string()
            }
        } catch (e: Exception) {
            // Любая сетевая ошибка — это null, а не падение приложения
            null
        }
    }
}
