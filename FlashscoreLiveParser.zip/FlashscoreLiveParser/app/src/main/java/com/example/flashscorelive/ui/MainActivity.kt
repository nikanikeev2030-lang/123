package com.example.flashscorelive.ui

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.flashscorelive.R
import com.example.flashscorelive.data.MatchRepository
import com.example.flashscorelive.databinding.ActivityMainBinding
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Главный экран: список live-матчей (или матчей дня, если live пуст).
 * Поддерживает pull-to-refresh и автообновление каждые 30 секунд.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val adapter = MatchAdapter()
    private val repository = MatchRepository()

    /** Job автообновления; отменяется в onDestroy. */
    private var autoRefreshJob: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.matchesList.layoutManager = LinearLayoutManager(this)
        binding.matchesList.adapter = adapter

        // Pull-to-refresh
        binding.swipeRefresh.setOnRefreshListener { refresh() }

        // Первая загрузка
        binding.swipeRefresh.isRefreshing = true
        refresh()

        // Автообновление каждые 30 секунд
        autoRefreshJob = lifecycleScope.launch {
            while (isActive) {
                delay(AUTO_REFRESH_INTERVAL_MS)
                refresh(showSpinner = false)
            }
        }
    }

    override fun onDestroy() {
        autoRefreshJob?.cancel()
        super.onDestroy()
    }

    /** Загружает и отображает матчи. */
    private fun refresh(showSpinner: Boolean = true) {
        if (showSpinner) binding.swipeRefresh.isRefreshing = true
        lifecycleScope.launch {
            val result = repository.loadMatches()
            binding.swipeRefresh.isRefreshing = false

            adapter.submit(result.leagues)

            // Подзаголовок: режим live / матчи дня
            binding.modeLabel.text = getString(
                if (result.isLive) R.string.mode_live else R.string.mode_today
            )

            // Пустые состояния
            when {
                result.isError -> showMessage(getString(R.string.error_network))
                result.leagues.isEmpty() -> showMessage(getString(R.string.empty_matches))
                else -> showMessage(null)
            }
        }
    }

    private fun showMessage(text: String?) {
        binding.emptyText.visibility = if (text == null) View.GONE else View.VISIBLE
        binding.emptyText.text = text.orEmpty()
    }

    private companion object {
        /** Интервал автообновления — 30 секунд. */
        const val AUTO_REFRESH_INTERVAL_MS = 30_000L
    }
}
