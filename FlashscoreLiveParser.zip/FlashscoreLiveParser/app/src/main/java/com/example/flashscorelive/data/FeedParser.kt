package com.example.flashscorelive.data

/**
 * Парсер внутреннего текстового feed Flashscore.
 *
 * Формат (классический flashscore):
 *  - записи разделены символом '¬';
 *  - поля внутри записи разделены '~' в виде КЛЮЧ~значение
 *    (первая пара может идти без ведущего '~');
 *  - запись с полем ZA — заголовок лиги (ZB — страна), она начинает блок матчей;
 *  - записи с полем AA — матчи:
 *      AA — id матча, AD — unix-timestamp начала, AB — код стадии,
 *      AE — домашняя команда, AF — гостевая, AG — счёт домашних,
 *      AH — счёт гостей, AO — минута матча ("45+2"), AJ — статус.
 *
 * Парсер отказоустойчив: неизвестные поля и битые записи игнорируются.
 * Ответ "0" (пустой feed) и null — это НЕ ошибка, просто пустой список.
 */
object FeedParser {

    /** Разделитель записей в feed. */
    private const val RECORD_SEPARATOR = '¬'

    /** Разделитель полей внутри записи. */
    private const val FIELD_SEPARATOR = '~'

    /** Маркер пустого ответа от сервера. */
    private const val EMPTY_FEED_MARKER = "0"

    /**
     * Разбирает тело ответа feed в список лиг с матчами.
     *
     * @param body тело ответа; null, пустая строка или "0" -> пустой список.
     * @return список лиг, каждая со своими матчами (порядок как в feed).
     */
    fun parse(body: String?): List<League> {
        // null / пусто / маркер "нет данных" — не ошибка
        val text = body?.trim().orEmpty()
        if (text.isEmpty() || text == EMPTY_FEED_MARKER) return emptyList()

        val leagues = mutableListOf<League>()

        // Текущая лига: имя, страна и накапливаемые матчи
        var currentLeagueName: String? = null
        var currentLeagueCountry: String = ""
        var currentMatches = mutableListOf<Match>()

        // Сбрасывает накопленную лигу в результат
        fun flushLeague() {
            val name = currentLeagueName
            if (name != null && currentMatches.isNotEmpty()) {
                leagues += League(
                    name = name,
                    country = currentLeagueCountry,
                    matches = currentMatches.toList(),
                )
            }
            currentMatches = mutableListOf()
        }

        for (record in text.split(RECORD_SEPARATOR)) {
            if (record.isBlank()) continue
            val fields = parseRecord(record)

            // Заголовок лиги: ZA = название, ZB = страна
            val leagueName = fields["ZA"]
            if (leagueName != null) {
                flushLeague()
                currentLeagueName = decode(leagueName)
                currentLeagueCountry = fields["ZB"]?.let(::decode).orEmpty()
                continue
            }

            // Запись матча: наличие поля AA (id)
            val matchId = fields["AA"]
            if (matchId != null) {
                val status = resolveStatus(fields)
                currentMatches += Match(
                    id = matchId,
                    home = fields["AE"]?.let(::decode).orEmpty(),
                    away = fields["AF"]?.let(::decode).orEmpty(),
                    homeScore = fields["AG"]?.toIntOrNull(),
                    awayScore = fields["AH"]?.toIntOrNull(),
                    minute = fields["AO"]?.takeIf { it.isNotBlank() },
                    status = status,
                    startTimestamp = fields["AD"]?.toLongOrNull(),
                    leagueName = currentLeagueName.orEmpty(),
                )
            }
            // Прочие записи (неизвестные ключи) — игнорируем
        }
        flushLeague()
        return leagues
    }

    /**
     * Разбирает одну запись "КЛЮЧ~значение~КЛЮЧ~значение..." в map.
     * Первая пара может идти без ведущего '~'.
     */
    private fun parseRecord(record: String): Map<String, String> {
        val result = LinkedHashMap<String, String>()
        val tokens = record.split(FIELD_SEPARATOR)
        var i = 0
        // Если запись начинается с '~', первый токен пустой — пропускаем
        if (tokens.isNotEmpty() && tokens[0].isEmpty()) i = 1
        while (i + 1 < tokens.size + 1 && i < tokens.size) {
            val key = tokens[i]
            val value = if (i + 1 < tokens.size) tokens[i + 1] else ""
            if (key.isNotEmpty()) result[key] = value
            i += 2
        }
        return result
    }

    /**
     * Определяет статус матча «наилучшим образом» по доступным полям.
     *
     * Логика:
     *  - есть минута (AO) -> матч идёт (LIVE), "HALF"/перерыв -> HALF_TIME;
     *  - в AB встречаются коды окончания ("FT", "AET", "Pen" и т.п.) -> FINISHED;
     *  - счёт есть, но матч не live и timestamp в прошлом — считаем завершённым;
     *  - есть только timestamp начала -> SCHEDULED;
     *  - иначе UNKNOWN.
     */
    private fun resolveStatus(fields: Map<String, String>): MatchStatus {
        val minute = fields["AO"]
        if (!minute.isNullOrBlank()) {
            val lower = minute.lowercase()
            return if (lower.contains("half") || lower == "ht") MatchStatus.HALF_TIME
            else MatchStatus.LIVE
        }

        val stage = fields["AB"].orEmpty().uppercase()
        val statusCode = fields["AJ"].orEmpty().uppercase()
        val finishedMarkers = listOf("FT", "AET", "PEN", "FINISHED", "ENDED")
        if (finishedMarkers.any { stage.contains(it) || statusCode.contains(it) }) {
            return MatchStatus.FINISHED
        }

        val hasScore = fields["AG"]?.toIntOrNull() != null || fields["AH"]?.toIntOrNull() != null
        val start = fields["AD"]?.toLongOrNull()
        if (hasScore && start != null) {
            // Счёт есть, минуты нет и матч давно начался -> вероятно, завершён
            val nowSeconds = System.currentTimeMillis() / 1000
            if (start < nowSeconds - 3 * 3600) return MatchStatus.FINISHED
            return MatchStatus.LIVE
        }

        if (start != null) return MatchStatus.SCHEDULED
        return MatchStatus.UNKNOWN
    }

    /**
     * Минимальное декодирование текстовых значений feed.
     * Flashscore иногда кодирует символы в названиях; неизвестные
     * последовательности оставляем как есть (отказоустойчивость).
     */
    private fun decode(raw: String): String = raw.trim()
}
