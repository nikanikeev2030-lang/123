# Флэшскор: Лайв — парсер live футбольных матчей

Android-приложение на Kotlin, которое показывает live-матчи футбола
с Flashscore. Публичного API у Flashscore нет, поэтому используется
внутренний текстовый feed мобильного сайта.

## Источник данных

| Назначение | URL |
|---|---|
| Live-матчи | `https://d.flashscore.com/x/feed/f_1_0_3_ru_1` |
| Матчи на сегодня (fallback) | `https://d.flashscore.com/x/feed/f_1_0_1_ru_1` |

Обязательные заголовки запроса:

```
x-fsign: SW9D1eZo
User-Agent: Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/124.0 Mobile
```

Ответ — `text/plain`. Тело `"0"` означает «данных нет» (пустой feed),
это **не** ошибка: приложение переключается на матчи дня.

### Формат feed

- Записи разделены символом `¬`.
- Поля внутри записи разделены `~` в виде `КЛЮЧ~значение...`
  (первая пара может идти без ведущего `~`).
- Запись с полем `ZA` — заголовок лиги (`ZB` — страна), начинает блок матчей.
- Записи с полем `AA` — матчи:
  - `AA` — id матча, `AD` — unix-timestamp начала, `AB` — код стадии,
  - `AE` — домашняя команда, `AF` — гостевая,
  - `AG`/`AH` — счёт, `BA`/`BB` — счёт 1-го тайма,
  - `AO` — минута матча (например `45+2`), `AJ` — статус.

Парсер (`FeedParser`) отказоустойчив: неизвестные поля игнорируются.

## Архитектура

```
app/src/main/java/com/example/flashscorelive/
├── data/
│   ├── Models.kt           # Match, MatchStatus, League
│   ├── FlashscoreApi.kt    # OkHttp GET с заголовками, String? (null при ошибке сети)
│   ├── FeedParser.kt       # чистый Kotlin-парсер feed -> List<League>
│   └── MatchRepository.kt  # live; если пусто («0») — матчи дня
└── ui/
    ├── MainActivity.kt     # список, SwipeRefresh, автообновление 30 сек
    └── MatchAdapter.kt     # заголовки лиг + строки матчей
```

- minSdk 26, targetSdk 34, Gradle Kotlin DSL, AGP 8.5.2, Gradle 8.7.
- Зависимости: OkHttp 4.12, kotlinx-coroutines, RecyclerView,
  SwipeRefreshLayout, ViewBinding. DI-фреймворки не используются.
- Тёмная тема, тёплые нейтральные низкосатурационные цвета
  (`res/values/colors.xml`).

## Сборка

### В Android Studio (рекомендуется)

1. Установите Android Studio (Koala+) с Android SDK 34.
2. **File → Open** → выберите папку проекта.
3. Дождитесь Gradle-синхронизации (wrapper скачает Gradle 8.7 автоматически).
4. **Run ▶** для запуска на устройстве/эмуляторе (Android 8.0+).

### Из командной строки

```bash
# Требуется JDK 17 и Android SDK (ANDROID_HOME)
./gradlew :app:assembleDebug          # APK: app/build/outputs/apk/debug/
./gradlew :app:testDebugUnitTest      # unit-тесты парсера
```

## Тесты

`app/src/test/java/com/example/flashscorelive/FeedParserTest.kt` — JUnit-тесты
на встроенном снапшоте feed (2 лиги, 3 матча: live со счётом и минутой,
запланированный, завершённый) + проверки пустого ответа `"0"`, лиги без матчей
и первой пары полей без ведущего `~`.

## Известные ограничения

- **Нет официального API.** Feed — внутренний, его формат и URL могут
  измениться в любой момент без предупреждения.
- **Ключ `x-fsign` (`SW9D1eZo`) периодически меняется** на стороне
  Flashscore — тогда запросы начнут возвращать ошибку/пустоту, ключ нужно
  будет обновить в `FlashscoreApi.kt`.
- Семантика кодов стадий (`AB`, `AJ`) недокументирована; статус матча
  определяется эвристически (минута → live, `FT`/`AET` → завершён и т.д.).
- Приложение не хранит историю и не показывает детали матча — только список.
